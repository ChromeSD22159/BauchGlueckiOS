//
//  ThemeLayout.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 19.11.24.
//

import Foundation
 
struct ThemeLayout {
    var padding: CGFloat = 10
    var radius: CGFloat = 10
}
