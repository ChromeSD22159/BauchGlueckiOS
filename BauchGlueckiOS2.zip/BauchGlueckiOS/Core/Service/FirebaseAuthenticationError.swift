//
//  FirebaseAuthenticationError.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 14.11.24.
//

enum FirebaseAuthenticationError: Error {
    case runtimeError(String)
}
