//
//  ScrollOffsetNamespace.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 05.11.24.
//

enum ScrollOffsetNamespace {
    static let namespace = "scrollView"
}
