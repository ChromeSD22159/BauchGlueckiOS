//
//  NextMedicationForToday.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 30.10.24.
//

import Foundation

struct NextMedicationForToday {
    var medication: Medication
    var intakeTime: Date
}
