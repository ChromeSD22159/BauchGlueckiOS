//
//  ApiDeviceToken.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 25.10.24.
//

struct ApiDeviceToken: Codable {
    var userID: String
    var token: String
}


