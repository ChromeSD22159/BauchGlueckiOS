//
//  WeeklyAverage.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 30.10.24.
//
import SwiftUI

struct WeeklyAverage {
    var avgValue: Double
    let week: Date
}
