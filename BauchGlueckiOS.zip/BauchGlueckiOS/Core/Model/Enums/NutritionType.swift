//
//  NutritionType.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 06.11.24.
//

enum NutritionType {
    case protein, carbs, sugar, fat
}
