//
//  FirebaseAppSettings.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 14.11.24.
//

struct FirebaseAppSettings: Codable {
    var showOpenAd: Bool
    var backendSyncing: Bool
}
