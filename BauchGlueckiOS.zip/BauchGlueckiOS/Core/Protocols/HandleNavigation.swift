//
//  HandleNavigation.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 18.10.24.
//

protocol HandleNavigation {
    func handleNavigation(screen: Screen)
}
