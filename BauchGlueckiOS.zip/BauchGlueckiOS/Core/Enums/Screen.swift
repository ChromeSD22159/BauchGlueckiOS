//
//  Screen.swift
//  BauchGlueckiOS
//
//  Created by Frederik Kohler on 18.10.24.
//

enum Screen {
    case Login, Register, ForgotPassword, Home, Launch
}
